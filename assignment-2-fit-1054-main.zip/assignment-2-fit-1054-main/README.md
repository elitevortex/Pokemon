# Assignment 2 Template - Pork Belly

Repository for Assignment 2 

## Group Members

- Felicity Matthews (fmat0007@student.monash.edu)
- Virani Aboetan (vabo0001@student.monash.edu)
- Edward Chan (echa0081@student.monash.edu)
- Dylan Thai (dtha0025@student.monash.edu)

## Implement the code!

- [x] Create the repository
- [x] Task 1
- [x] Task 2
- [x] Task 3
- [x] Task 4
- [x] Task 5
- [x] Task 6

## tests and comments:
- [x] Task 1
- [x] Task 2
- [x] Task 3
- [x] Task 4
- [x] Task 5
- [x] Task 6

